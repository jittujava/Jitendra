package com.example.casesyncservice.model;

public enum LifeCycleStatus {
}
