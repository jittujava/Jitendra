package com.example.casesyncservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotesData {

    private String status;
    private String transactionType;
    private String categoryId;
    private String region;
    private String userType;
    private String notesContent;
    private String fileName;
    private byte[] fileContent;
}
