package com.example.casesyncservice.model;

import lombok.Data;

import java.util.List;

@Data
public class Cases {
    public List<CaseItem> value;
}
