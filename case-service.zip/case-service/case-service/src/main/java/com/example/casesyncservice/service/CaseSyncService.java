package com.example.casesyncservice.service;

public interface CaseSyncService {

    void syncCaseStatus();
}
