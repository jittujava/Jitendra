package com.example.casesyncservice.mapper;

import com.example.casesyncservice.dto.NotesDto;
import com.example.casesyncservice.entity.Notes;

public class NotesMapper {

    public static NotesDto mapToNotesDto(Notes notes){
        return new NotesDto(
                notes.getId(),
                notes.getHostObjectId(),
                notes.getHostObjectType(),
                notes.getHtmlContent(),
                notes.getPlainContent(),
                notes.getNoteTypeCode(),
                notes.getIsInternal(),
                notes.getCreatedOn(),
                notes.getCreatedBy(),
                notes.getUpdatedOn(),
                notes.getUpdatedBy()
        );
    }

    public static Notes mapToNotes(NotesDto notesDto){
        return new Notes(
                notesDto.getId(),
                notesDto.getHostObjectId(),
                notesDto.getHostObjectType(),
                notesDto.getHtmlContent(),
                notesDto.getPlainContent(),
                notesDto.getNoteTypeCode(),
                notesDto.getIsInternal(),
                notesDto.getCreatedOn(),
                notesDto.getCreatedBy(),
                notesDto.getUpdatedOn(),
                notesDto.getUpdatedBy()
        );
    }
}
