package com.example.casesyncservice.controller;

import com.example.casesyncservice.dto.DocumentsDto;
import com.example.casesyncservice.dto.NotesDto;
import com.example.casesyncservice.entity.Documents;
import com.example.casesyncservice.entity.Notes;
import com.example.casesyncservice.service.DocumentService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/documents/api")
public class DownloadApiController {

    private DocumentService documentService;

    @GetMapping("/downloadChecking")
    public ResponseEntity<String> getDownloadMessage() {
        return ResponseEntity.ok("Download API is working fine");
    }

    @PostMapping("/createDocs")
        public ResponseEntity<DocumentsDto> createDocumentDummyData(@RequestBody DocumentsDto documentsDto) {
        DocumentsDto documents = documentService.createDocuments(documentsDto);
        return ResponseEntity.ok(documents);
    }

    @GetMapping("/getDocuments/{hostObjectType}")
    public ResponseEntity<List<Documents>> getDocumentsById(@PathVariable("hostObjectType") Long hostObjectType){
        List<Documents> documents = documentService.getDocumentsById(hostObjectType);
        return ResponseEntity.ok(documents);
    }
}
