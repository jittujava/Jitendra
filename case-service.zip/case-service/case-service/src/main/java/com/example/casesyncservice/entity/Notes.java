package com.example.casesyncservice.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Notes")

public class Notes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "hostObjectId")
    private String hostObjectId;
    @Column(name = "hostObjectType")
    private Long hostObjectType;
    @Column(name = "htmlContent")
    private String htmlContent;
    @Column(name = "plainContent")
    private String plainContent;
    @Column(name = "noteTypeCode")
    private String noteTypeCode;
    @Column(name = "isInternal")
    private String isInternal;
    @Column(name = "created_on")
    private String createdOn;
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "updated_on")
    private String updatedOn;
    @Column(name = "updated_by")
    private String updatedBy;

}
