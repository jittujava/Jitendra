package com.example.casesyncservice.dto;

import com.example.casesyncservice.entity.Notes;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DocumentsDto {

    private int documentId;
    private String title;
    private String fileName;
    private String category;
    private String status;
    private String thumbnailStatus;
    private Long type;
    private String typeDescription;
    private String contentType;
    private Set<Notes> plainContent;
    private String createdOn;
    private String createdBy;
    private String updatedOn;
    private String updatedBy;
    private String updatedByName;
    private String hostObjectId;
    private Long hostObjectType;
    private String icon;
    private String color;

    public DocumentsDto(int documentId, String title, String fileName, String category, String status, String thumbnailStatus, Long type, String typeDescription, String contentType, String createdOn, String createdBy, String updatedOn, String updatedBy, String updatedByName, String hostObjectId, Long hostObjectType, String icon, String color) {
        this.documentId = documentId;
        this.title = title;
        this.fileName = fileName;
        this.category = category;
        this.status = status;
        this.thumbnailStatus = thumbnailStatus;
        this.type = type;
        this.typeDescription = typeDescription;
        this.contentType = contentType;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.updatedOn = updatedOn;
        this.updatedBy = updatedBy;
        this.updatedByName = updatedByName;
        this.hostObjectId = hostObjectId;
        this.hostObjectType = hostObjectType;
        this.icon = icon;
        this.color = color;
    }
}
