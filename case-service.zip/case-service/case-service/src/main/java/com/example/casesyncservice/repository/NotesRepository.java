package com.example.casesyncservice.repository;

import com.example.casesyncservice.entity.Notes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface NotesRepository extends JpaRepository<Notes, Long> {

    @Query(value = "SELECT * FROM Notes n WHERE n.host_object_type = ?1", nativeQuery = true)
    public List<Notes> getNotesById(@Param("hostObjectType") Long hostObjectType);
}
