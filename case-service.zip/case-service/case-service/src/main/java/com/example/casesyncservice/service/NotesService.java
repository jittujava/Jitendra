package com.example.casesyncservice.service;

import com.example.casesyncservice.dto.NotesDto;
import com.example.casesyncservice.entity.Notes;

import java.util.List;

public interface NotesService {
    
    NotesDto createNotes(NotesDto notesDto);

    NotesDto updateNotes(Long caseId ,NotesDto notesDto);

    List<NotesDto> getNotes();

    public List<Notes> getNotesById(Long hostObjectType);

}
