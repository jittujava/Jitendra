package com.example.casesyncservice.dto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class NotesDto {

    private Long id;
    private String hostObjectId;
    private Long hostObjectType;
    private String htmlContent;
    private String plainContent;
    private String noteTypeCode;
    private String isInternal;
    private String createdOn;
    private String createdBy;
    private String updatedOn;
    private String updatedBy;
}
