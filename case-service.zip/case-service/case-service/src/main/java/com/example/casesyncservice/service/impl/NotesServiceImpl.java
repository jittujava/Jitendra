package com.example.casesyncservice.service.impl;

import com.example.casesyncservice.dto.NotesDto;
import com.example.casesyncservice.entity.Notes;
import com.example.casesyncservice.mapper.NotesMapper;
import com.example.casesyncservice.repository.NotesRepository;
import com.example.casesyncservice.service.NotesService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Service
@AllArgsConstructor
public class NotesServiceImpl implements NotesService {

    private NotesRepository notesRepository;

    private static String FIND_NOTES_BY_ID = "SELECT * FROM Notes n WHERE n.hostObjectType = ?";

    @Override
    public NotesDto createNotes(NotesDto notesDto) {
        Notes notes = NotesMapper.mapToNotes(notesDto);
        Notes savedNotes = notesRepository.save(notes);
        return NotesMapper.mapToNotesDto(savedNotes);
    }

    @Override
    public NotesDto updateNotes(Long caseId, NotesDto notesDto) {
        return null;
    }

    @Override
    public List<NotesDto> getNotes() {
        List<Notes> notes = notesRepository.findAll();
        /*.orElseThrow(
                ()-> new RuntimeException("Provided host object ID doesn't exist in system..." + hostObjectType)
        );
        return NotesMapper.mapToNotesDto(notes);*/
        return notes.stream().map(notes1 -> NotesMapper.mapToNotesDto(notes1)).collect(Collectors.toList());
    }

    @Override
    public List<Notes> getNotesById(Long hostObjectType) {
        return notesRepository.getNotesById(hostObjectType);
    }
}
