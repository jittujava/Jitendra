package com.example.casesyncservice.mapper;

import com.example.casesyncservice.dto.DocumentsDto;
import com.example.casesyncservice.entity.Documents;

public class DocumentsMapper {

    public static DocumentsDto mapToDocumentsDto(Documents documents){
        return new DocumentsDto(
                documents.getDocumentId(),
                documents.getTitle(),
                documents.getFileName(),
                documents.getCategory(),
                documents.getStatus(),
                documents.getThumbnailStatus(),
                documents.getType(),
                documents.getTypeDescription(),
                documents.getContentType(),
                documents.getCreatedOn(),
                documents.getCreatedBy(),
                documents.getUpdatedOn(),
                documents.getUpdatedBy(),
                documents.getUpdatedByName(),
                documents.getHostObjectId(),
                documents.getHostObjectType(),
                documents.getIcon(),
                documents.getColor()
        );
    }

    public static Documents mapToDocuments(DocumentsDto documentsDto){
        return new Documents(
                documentsDto.getDocumentId(),
                documentsDto.getTitle(),
                documentsDto.getFileName(),
                documentsDto.getCategory(),
                documentsDto.getStatus(),
                documentsDto.getThumbnailStatus(),
                documentsDto.getType(),
                documentsDto.getTypeDescription(),
                documentsDto.getContentType(),
                documentsDto.getCreatedOn(),
                documentsDto.getCreatedBy(),
                documentsDto.getUpdatedOn(),
                documentsDto.getUpdatedBy(),
                documentsDto.getUpdatedByName(),
                documentsDto.getHostObjectId(),
                documentsDto.getHostObjectType(),
                documentsDto.getIcon(),
                documentsDto.getColor(),
                documentsDto.getPlainContent()
        );
    }
}
