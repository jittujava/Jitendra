package com.example.casesyncservice.controller;


import com.example.casesyncservice.dto.NotesDto;
import com.example.casesyncservice.entity.Notes;
import com.example.casesyncservice.exception.CaseSyncException;
import com.example.casesyncservice.model.CaseNotes;
import com.example.casesyncservice.model.NotesData;
import com.example.casesyncservice.service.NotesService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/notes/api")
public class CaseNotesController {

    private NotesService notesService;

    @GetMapping("/hello")
    public String helloNotes() {
        return "Hello Case Notes";
    }

    @PostMapping(value = "/updateNotes/case/{hostObjectId}", consumes = {"multipart/form-data"})
    public ResponseEntity<? extends Object> processCaseNotes(@PathVariable final String hostObjectId,
                                                             @RequestPart("notes") String notesJson,
                                                             @RequestPart("file") MultipartFile file) {
        CaseNotes notes;
        try {
            notes = new ObjectMapper().readValue(notesJson, CaseNotes.class);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Invalid notes JSON format");
        }

        log.info("Host ObjectId is {}: ", hostObjectId);
        log.info("Status is {}: ", notes.getStatus());
        log.info("TransactionType is {}: ", notes.getTransactionType());
        log.info("CategoryId is {}: ", notes.getCategoryId());
        log.info("Notes Content is {}: ", notes.getNotesContent());

        if (file.isEmpty()) {
            throw new CaseSyncException(HttpStatus.BAD_REQUEST, "File is Empty");
        }
        try {
            byte[] bytes = file.getBytes();
            String fileName = file.getOriginalFilename();
            log.info("Attached File content is: {}", new String(bytes, StandardCharsets.UTF_8));
            NotesData notesData = new NotesData(notes.getStatus(), notes.getTransactionType(),
                    notes.getCategoryId(), notes.getRegion(), notes.getUserType(), notes.getNotesContent(),
                    fileName, bytes);
            byte[] jsonBytes = new ObjectMapper().writeValueAsBytes(notesData);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"notes-data.json\"")
                    .contentLength(jsonBytes.length)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(new InputStreamResource(new ByteArrayInputStream(jsonBytes)));
        } catch (IOException e) {
            log.error("Error processing file or notes data", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to process notes-data");
        }
    //return null;
    }

    @PostMapping("/createNotes")
    public ResponseEntity<NotesDto> createNotes(@RequestBody NotesDto notesDto) {
        NotesDto notes = notesService.createNotes(notesDto);
        return ResponseEntity.ok(notes);
    }

    @GetMapping("/getNotes")
    public ResponseEntity<List<NotesDto>> getNotesByHostObjectId(){
        List<NotesDto> notes = notesService.getNotes();
        return ResponseEntity.ok(notes);
    }

    @GetMapping("/getNotes/{hostObjectType}")
    public ResponseEntity<List<Notes>> getNotesById(@PathVariable("hostObjectType") Long hostObjectType){
        List<Notes> notes = notesService.getNotesById(hostObjectType);
        return ResponseEntity.ok(notes);
    }

}
