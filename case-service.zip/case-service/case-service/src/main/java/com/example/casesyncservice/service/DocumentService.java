package com.example.casesyncservice.service;

import com.example.casesyncservice.dto.DocumentsDto;
import com.example.casesyncservice.dto.NotesDto;
import com.example.casesyncservice.entity.Documents;
import com.example.casesyncservice.entity.Notes;

import java.util.List;

public interface DocumentService {

    DocumentsDto createDocuments(DocumentsDto documentsDto);

    public List<Documents> getDocumentsById(Long hostObjectType);
}
