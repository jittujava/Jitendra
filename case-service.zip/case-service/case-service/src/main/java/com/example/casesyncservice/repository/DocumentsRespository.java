package com.example.casesyncservice.repository;

import com.example.casesyncservice.entity.Documents;
import com.example.casesyncservice.entity.Notes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DocumentsRespository extends JpaRepository<Documents, Long> {

    @Query(value = "select doc.document_id, doc.title, doc.file_name, doc.category, doc.status, doc.thumbnail_status, doc.type, doc.type_description, doc.content_type,n.html_content, n.plain_content,\n" +
            " doc.created_by, doc.created_on, doc.updated_by, doc.updated_by_name, doc.updated_on, doc.host_object_id, doc.host_object_type, doc.icon, doc.color from notes n, document_details doc where n.host_object_type = doc.host_object_type and doc.host_object_type=?1", nativeQuery = true)
    public List<Documents> getDocumentsById(@Param("hostObjectType") Long hostObjectType);
}
