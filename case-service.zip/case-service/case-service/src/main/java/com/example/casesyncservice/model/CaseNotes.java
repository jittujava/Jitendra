package com.example.casesyncservice.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseNotes {

    @NotNull
    private String status;
    @NotNull
    private String transactionType;
    @NotNull
    private String categoryId;

    private String region;

    private String userType;

    private String notesContent;
}
