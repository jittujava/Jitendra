package com.example.casesyncservice.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Document_Details")

public class Documents {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int documentId;
    @Column(name = "title")
    private String title;
    @Column(name = "fileName")
    private String fileName;
    @Column(name = "category")
    private String category;
    @Column(name = "status")
    private String status;
    @Column(name = "thumbnailStatus")
    private String thumbnailStatus;
    @Column(name = "type")
    private Long type;
    @Column(name = "typeDescription")
    private String typeDescription;
    @Column(name = "contentType")
    private String contentType;
    @Column(name = "createdOn")
    private String createdOn;
    @Column(name = "createdBy")
    private String createdBy;
    @Column(name = "updatedOn")
    private String updatedOn;
    @Column(name = "updatedBy")
    private String updatedBy;
    @Column(name = "updatedByName")
    private String updatedByName;
    @Column(name = "hostObjectId")
    private String hostObjectId;
    @Column(name = "hostObjectType")
    private Long hostObjectType;
    @Column(name = "icon")
    private String icon;
    @Column(name = "color")
    private String color;

    @OneToMany
    @JoinColumn(name = "hostObjectType", referencedColumnName = "hostObjectType")
    private Set<Notes> notes;


    
}
