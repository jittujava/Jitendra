package com.example.casesyncservice.service.impl;

import com.example.casesyncservice.dto.DocumentsDto;
import com.example.casesyncservice.dto.NotesDto;
import com.example.casesyncservice.entity.Documents;
import com.example.casesyncservice.entity.Notes;
import com.example.casesyncservice.mapper.DocumentsMapper;
import com.example.casesyncservice.mapper.NotesMapper;
import com.example.casesyncservice.repository.DocumentsRespository;
import com.example.casesyncservice.service.DocumentService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class DocumentServiceImpl implements DocumentService {

    private DocumentsRespository documentsRespository;

    @Override
    public DocumentsDto createDocuments(DocumentsDto documentsDto) {
        Documents doc = DocumentsMapper.mapToDocuments(documentsDto);
        Documents documents = documentsRespository.save(doc);
        return DocumentsMapper.mapToDocumentsDto(documents);
    }

    @Override
    public List<Documents> getDocumentsById(Long hostObjectType) {
        return documentsRespository.getDocumentsById(hostObjectType);
    }
}
