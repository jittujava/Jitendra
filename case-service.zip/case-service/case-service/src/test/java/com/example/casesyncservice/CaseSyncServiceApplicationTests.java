package com.example.casesyncservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaseSyncServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
