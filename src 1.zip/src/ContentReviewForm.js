import React, { useState } from 'react';
import './ContentReviewForm.css'; // Import the CSS file

const ContentReviewForm = () => {
  const [status, setStatus] = useState('');
  const [transactionType, setTransactionType] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [content, setContent] = useState('');
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [caseId, setCaseId] = useState(''); // State for Case ID

  // State for checkboxes
  const [isSelectAllChecked, setIsSelectAllChecked] = useState(false);
  const [options, setOptions] = useState({
    option1: false,
    option2: false,
  });

  // State for modal visibility
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleSave = (e) => {
    e.preventDefault();
    // Add your save logic here
    alert('Form Saved!');
  };

  const handleCancel = () => {
    // Add your cancel logic here
    alert('Form Canceled!');
  };

  // Function to handle "Select All"
  const handleSelectAll = () => {
    const newSelectAllState = !isSelectAllChecked;  // Toggle the Select All state
    setIsSelectAllChecked(newSelectAllState);

    // Update all individual options based on the new Select All state
    setOptions({
      option1: newSelectAllState,
      option2: newSelectAllState,
    });
  };

  // Function to handle individual checkbox change
  const handleOptionChange = (e) => {
    const { name, checked } = e.target;
    setOptions({
      ...options,
      [name]: checked,
    });
  };

  // Function to open the modal
  const openModal = () => {
    setIsModalOpen(true);
  };

  // Function to close the modal
  const closeModal = () => {
    setIsModalOpen(false);
    setCaseId(''); // Reset Case ID when closing modal
    setOptions({ option1: false, option2: false }); // Reset options
    setIsSelectAllChecked(false); // Reset Select All
  };

  return (
    <form className="content-review-form" onSubmit={handleSave}>
      <div className="form-header">
        <h2>Content Review</h2>
      </div>

      <div className="form-group">
        <label>
          * Status:
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Select Status</option>
            <option value="Completed">Completed</option>
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
          </select>
        </label>
      </div>

      <div className="form-group">
        <label>
          * Transaction Type:
          <select value={transactionType} onChange={(e) => setTransactionType(e.target.value)}>
            <option value="">Select Transaction Type</option>
            <option value="Type 1">Type 1</option>
            <option value="Type 2">Type 2</option>
            <option value="Type 3">Type 3</option>
          </select>
        </label>
      </div>

      <div className="form-group">
        <label>
          * Category ID:
          <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
            <option value="">Select Category</option>
            <option value="Category 1">Category 1</option>
            <option value="Category 2">Category 2</option>
            <option value="Category 3">Category 3</option>
          </select>
        </label>
      </div>

      {/* Move the Attachment link and modal here */}
      <div className="form-group">
        <a
          href="#"
          className="redirect-link"
          onClick={(e) => {
            e.preventDefault(); // Prevent default anchor behavior
            openModal(); // Open modal when clicked
          }}
        >
          Attachment
        </a>
      </div>

      <div className="form-group">
        <label>
          Note:
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows="4"
          />
        </label>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3>Attachment</h3>

            <label>
              Case ID:
              <input
                type="text"
                value={caseId}
                onChange={(e) => setCaseId(e.target.value)}
              />
            </label>

            <label>
              <input
                type="checkbox"
                checked={isSelectAllChecked}
                onChange={handleSelectAll}
              />
              Select All
            </label>
            <label>
              <input
                type="checkbox"
                name="option1"
                checked={options.option1}
                onChange={handleOptionChange}
              />
              Option 1
            </label>
            <label>
              <input
                type="checkbox"
                name="option2"
                checked={options.option2}
                onChange={handleOptionChange}
              />
              Option 2
            </label>
            <button onClick={closeModal}>Close</button>
          </div>
        </div>
      )}

      <div className="form-group">
        <label>
          <input
            type="checkbox"
            checked={isConfirmed}
            onChange={(e) => setIsConfirmed(e.target.checked)}
          />
          I Confirm
        </label>
      </div>

      <div className="form-actions">
        <button type="submit">Save & Continue</button>
        <button type="button" onClick={handleCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
};

export default ContentReviewForm;
